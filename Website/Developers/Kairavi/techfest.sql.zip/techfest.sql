-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 28, 2019 at 06:38 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `techfest`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_pannel`
--

CREATE TABLE IF NOT EXISTS `admin_pannel` (
  `u_name` varchar(40) NOT NULL,
  `u_id` varchar(10) NOT NULL,
  `u_pass` varchar(20) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_pannel`
--

INSERT INTO `admin_pannel` (`u_name`, `u_id`, `u_pass`) VALUES
('atv2@gmail.com', 'ATV', 'mainatv2'),
('bshah@gmail.com', 'b5', 'bs12'),
('entresum@gmail.com', 'ENSM', 'mainentresum'),
('nontechevents@gmail.com', 'NONTECH', 'mainnontech'),
('robotics@gmail.com', 'ROBO', 'mainrobotics'),
('techevents@gmail.com', 'TECH', 'maintechevent'),
('main@gmail.com', 'WEB', 'mainwebteam'),
('workshop@gmail.com', 'WKSP', 'mainworkshop');

-- --------------------------------------------------------

--
-- Table structure for table `atv`
--

CREATE TABLE IF NOT EXISTS `atv` (
  `e_name` varchar(40) NOT NULL,
  `abstract` varchar(20) NOT NULL,
  `rules` varchar(58) NOT NULL,
  `fees` int(5) NOT NULL,
  `min_members` int(2) NOT NULL,
  `max_members` int(2) NOT NULL,
  `scope` int(5) NOT NULL,
  PRIMARY KEY (`e_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `atv`
--

INSERT INTO `atv` (`e_name`, `abstract`, `rules`, `fees`, `min_members`, `max_members`, `scope`) VALUES
('aaaa', 'gkg', '<p>ukkoypi</p>', 0, 0, 0, 0),
('ATV', '', '', 0, 0, 0, 0),
('fsdfdgh', 'egdfhtfht', '<p>fgsdhdhjed</p>', 0, 0, 0, 0),
('hfhgj', 'gkj', 'jjkh                    ', 0, 0, 0, 0),
('hhlgjk', 'hvhbk', '<p>hghgk</p>', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `d_id` varchar(11) NOT NULL,
  `d_name` varchar(40) NOT NULL,
  PRIMARY KEY (`d_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`d_id`, `d_name`) VALUES
('D1', 'Tech'),
('D2', 'non-tech'),
('D3', 'ATV'),
('D4', 'Robotics'),
('D5', 'Workshop'),
('D6', 'EntreSum');

-- --------------------------------------------------------

--
-- Table structure for table `entresum`
--

CREATE TABLE IF NOT EXISTS `entresum` (
  `e_name` varchar(40) NOT NULL,
  `abstract` varchar(20) NOT NULL,
  `rules` varchar(58) NOT NULL,
  `fees` int(5) NOT NULL,
  `min_members` int(2) NOT NULL,
  `max_members` int(2) NOT NULL,
  `scope` int(5) NOT NULL,
  PRIMARY KEY (`e_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `entresum`
--

INSERT INTO `entresum` (`e_name`, `abstract`, `rules`, `fees`, `min_members`, `max_members`, `scope`) VALUES
('aaaaa', 'ffddd', '<p>ddutfuy</p>', 0, 0, 0, 0),
('bhghjg', 'hggg', '<p>gugygi</p><p>uuggi</p><p>gihho</p>', 0, 0, 0, 0),
('BIZQUIZ', '', '', 40, 1, 1, 0),
('CROWDPITCH', '', '', 0, 1, 1, 0),
('fefsese', 'eerew', '<p>dfdsfsd</p>', 0, 0, 0, 0),
('Hackathon', '', '', 0, 3, 5, 0),
('IPL Auction', '', '', 300, 2, 5, 0),
('Panel Discussion(Startup India)', '', '', 0, 1, 1, 0),
('Startup Fair + Minutes to Millionaire', '', '', 0, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE IF NOT EXISTS `manager` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `action` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`id`, `name`, `phone`, `action`) VALUES
(15, 'kairavi', '8866882346', 1),
(16, 'shah', '8866882458', 0);

-- --------------------------------------------------------

--
-- Table structure for table `non_tech`
--

CREATE TABLE IF NOT EXISTS `non_tech` (
  `e_name` varchar(40) NOT NULL,
  `abstract` varchar(20) NOT NULL,
  `rules` varchar(58) NOT NULL,
  `fees` int(5) NOT NULL,
  `min_members` int(2) NOT NULL,
  `max_members` int(2) NOT NULL,
  `scope` int(5) NOT NULL,
  PRIMARY KEY (`e_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `non_tech`
--

INSERT INTO `non_tech` (`e_name`, `abstract`, `rules`, `fees`, `min_members`, `max_members`, `scope`) VALUES
('1 minute Game', '', '', 0, 1, 1, 0),
('aaaaHVJ', 'jkhjh', '<p>jhjhjkhk</p>', 0, 0, 0, 0),
('Being Sherlock', '', '', 0, 1, 4, 0),
('Catapult', '', '', 0, 1, 1, 0),
('CineJam', '', '', 0, 2, 3, 0),
('CLICK - FLIX', '', '', 0, 1, 2, 0),
('Counter Strike', '', '', 0, 5, 5, 0),
('Distraction', '', '', 0, 1, 1, 0),
('HumanCaterpillar', '', '', 0, 4, 5, 0),
('Hurdles & Twister', '', '', 0, 2, 2, 0),
('Live Ludo', '', '', 0, 4, 4, 0),
('Mini Militia', '', '', 0, 3, 4, 0),
('Mock Parliament', '', '', 0, 1, 1, 0),
('NERD Quiz ', '', '', 0, 1, 1, 0),
('Paint IT Out', '', '', 0, 2, 2, 0),
('Paint War', '', '', 0, 4, 5, 0),
('Run Rotate Run', '', '', 0, 3, 3, 0),
('SelfieHolic', '', '', 0, 1, 1, 0),
('Slow Cycling', '', '', 0, 1, 1, 0),
('Story up ', '', '', 0, 1, 1, 0),
('Tug of war', '', '', 0, 5, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `college` varchar(100) NOT NULL,
  `enroll` bigint(15) DEFAULT NULL,
  `team_id` int(5) NOT NULL,
  `team_leader` varchar(20) NOT NULL,
  `team_name` varchar(80) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `fees` int(5) NOT NULL,
  `e_id` int(5) NOT NULL,
  `no_tmember` int(5) NOT NULL,
  `action` int(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `firstName`, `lastName`, `email`, `phone`, `college`, `enroll`, `team_id`, `team_leader`, `team_name`, `gender`, `fees`, `e_id`, `no_tmember`, `action`, `date`) VALUES
(19, 'fhfk', 'hjhkgkhg', 'abc@gmail.com', 164649989, 'bhgujg', 34649648, 12, 'hfyfuy', 'jghg', 'female', 0, 0, 0, 0, '2019-02-28 22:58:17'),
(21, 'fhfk', 'hjhkgkhg', 'abc@gmail.com', 164649989, 'bhgujg', 34649648, 14, 'hfyfuy', 'jghg', 'female', 0, 0, 0, 0, '2019-02-28 22:58:17');

-- --------------------------------------------------------

--
-- Table structure for table `robotics`
--

CREATE TABLE IF NOT EXISTS `robotics` (
  `e_name` varchar(40) NOT NULL,
  `abstract` varchar(20) NOT NULL,
  `rules` varchar(58) NOT NULL,
  `fees` int(5) NOT NULL,
  `min_members` int(2) NOT NULL,
  `max_members` int(2) NOT NULL,
  `scope` int(5) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`e_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `robotics`
--

INSERT INTO `robotics` (`e_name`, `abstract`, `rules`, `fees`, `min_members`, `max_members`, `scope`, `date`) VALUES
('aaaaa', 'fj', '<p>fu</p>', 0, 0, 0, 0, '0000-00-00 00:00:00'),
('Battle of Bots', '', '', 350, 2, 4, 0, '0000-00-00 00:00:00'),
('Death race', '', '', 250, 2, 4, 0, '0000-00-00 00:00:00'),
('Droid Hockey', '', '', 250, 2, 4, 0, '0000-00-00 00:00:00'),
('Hydrobot', '', '', 250, 2, 4, 0, '0000-00-00 00:00:00'),
('Line Follower', '', '', 250, 2, 4, 0, '0000-00-00 00:00:00'),
('Quadcopter', '', '', 350, 2, 4, 0, '0000-00-00 00:00:00'),
('Robo Puzzle', '', '', 250, 2, 4, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE IF NOT EXISTS `team` (
  `v_id` int(5) NOT NULL,
  `t_id` int(3) NOT NULL AUTO_INCREMENT,
  `t_nm` varchar(20) NOT NULL,
  `t_l` varchar(20) NOT NULL,
  `action` varchar(10) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`v_id`, `t_id`, `t_nm`, `t_l`, `action`, `date`) VALUES
(0, 13, 'aaa', 'a', '1', '0000-00-00 00:00:00'),
(0, 15, 'dd', 'd', '0', '0000-00-00 00:00:00'),
(1, 16, 'HHJ', 'HGKJ', '0', '2019-02-28 22:49:32'),
(2, 17, 'JGKG', 'KGKH', '0', '2019-02-28 20:49:44');

-- --------------------------------------------------------

--
-- Table structure for table `tech`
--

CREATE TABLE IF NOT EXISTS `tech` (
  `e_name` varchar(40) NOT NULL,
  `abstract` varchar(20) NOT NULL,
  `rules` varchar(58) NOT NULL,
  `fees` int(5) NOT NULL,
  `min_members` int(2) NOT NULL,
  `max_members` int(2) NOT NULL,
  `scope` int(5) NOT NULL,
  PRIMARY KEY (`e_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tech`
--

INSERT INTO `tech` (`e_name`, `abstract`, `rules`, `fees`, `min_members`, `max_members`, `scope`) VALUES
('Artifice', '', '', 200, 2, 4, 0),
('AUTO PSY', '', '', 300, 3, 5, 0),
('Breakup Bridge', '', '', 250, 3, 5, 0),
('C quiz And CryptoHunt', '', '', 200, 4, 0, 0),
('CAD ISTIC', '', '', 50, 1, 0, 0),
('Canon Wars', '', '', 250, 2, 5, 0),
('Cash Flow', '', '', 150, 1, 3, 0),
('Chain reaction', '', '', 250, 1, 0, 0),
('Chem-o-Click', '', '', 150, 2, 3, 0),
('Chem-o-live ', '', '', 200, 2, 4, 0),
('Circuit Chakravyuh', '', '', 150, 1, 3, 0),
('Civil Brainiacs', '', '', 120, 2, 4, 0),
('Code-less', '', '', 100, 1, 2, 0),
('CodeSaw', '', '', 100, 1, 2, 0),
('Colrefs', '', '', 150, 2, 4, 0),
('Corpo Quiz', '', '', 50, 1, 0, 0),
('Decode, Recode, Encode', '', '', 100, 1, 2, 0),
('Eagle Eye', '', '', 50, 1, 0, 0),
('Electric-o-buzz', '', '', 50, 1, 0, 0),
('Gate-o-Tarka', '', '', 100, 1, 2, 0),
('Hunt It Up', '', '', 250, 2, 5, 0),
('HYDRAULIC ARM', '', '', 250, 1, 3, 0),
('Junkyard', '', '', 300, 2, 4, 0),
('kjbjk', 'jbbk', '<p>bbkjbk</p>', 0, 0, 0, 0),
('Life of pile', '', '', 150, 2, 4, 0),
('Mad-Ads', '', '', 200, 2, 4, 0),
('Maths Treasurhunt', '', '', 150, 2, 3, 0),
('Mecha Treasure Hunt', '', '', 250, 1, 3, 0),
('Mock Interview', '', '', 50, 1, 0, 0),
('Paper Presentation', '', '', 100, 1, 2, 0),
('Photoshop-FACEOFF', '', '', 150, 3, 0, 0),
('Relay Coding', '', '', 200, 4, 0, 0),
('Smart Manager', '', '', 50, 1, 0, 0),
('Sod-i-Atic Car', '', '', 250, 2, 5, 0),
('Think Big', '', '', 100, 1, 2, 0),
('Traffica', '', '', 200, 2, 4, 0),
('Use solar - save nature', '', '', 200, 1, 4, 0),
('Waste 2 Shrrshtha', '', '', 100, 1, 2, 0),
('WebWeaver', '', '', 50, 1, 0, 0),
('Witricity', '', '', 150, 1, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `trial`
--

CREATE TABLE IF NOT EXISTS `trial` (
  `PASSWORD` varbinary(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trial`
--

INSERT INTO `trial` (`PASSWORD`) VALUES
('R�-R+��8�}z��v'),
('R�-R+��8�}z��v');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer`
--

CREATE TABLE IF NOT EXISTS `volunteer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `action` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `volunteer`
--

INSERT INTO `volunteer` (`id`, `name`, `phone`, `action`) VALUES
(25, 'kairavi', 8887975454, 0),
(26, 'shah', 8866882345, 0);

-- --------------------------------------------------------

--
-- Table structure for table `workshop`
--

CREATE TABLE IF NOT EXISTS `workshop` (
  `e_name` varchar(40) NOT NULL,
  `abstract` varchar(20) NOT NULL,
  `rules` varchar(58) NOT NULL,
  `fees` int(5) NOT NULL,
  `min_members` int(2) NOT NULL,
  `max_members` int(2) NOT NULL,
  `scope` int(5) NOT NULL,
  PRIMARY KEY (`e_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workshop`
--

INSERT INTO `workshop` (`e_name`, `abstract`, `rules`, `fees`, `min_members`, `max_members`, `scope`) VALUES
('aaaa', 'ghjgjg', '<p>gkggkhk</p>', 0, 0, 0, 0),
('nfkdsk', 'llkhlhl', '<p>fnsljsljd;s</p><p>dnksdnsdl</p><p>,nklndskd</p><p>nnkls', 0, 0, 0, 0);
