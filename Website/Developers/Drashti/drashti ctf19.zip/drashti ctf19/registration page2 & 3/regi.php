<?php
$member=$_POST['members']
?>
<html>
<head>
	<title></title>
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.slim.min.js"></script>
	<script type="text/javascript" src="js/propper.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/validate.js"></script>
	
	<link rel="stylesheet" type="text/css" href="css/reg.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<style type="text/css">
	<!--	.hidden2 {
			display: none;
		}
		.hidden3 {
			display: none;
		}
		.hidden4 {
			display: none;
		}-->
	</style>
</head>

<body>
	<div class="box2">
			<div class="row">
				<div class="col-sm-2 col-md-2"></div>
				<div class="col-sm-8 col-md-8">

					<h1 class="title">Registration</h1>
					<br>


				<form action="regi2.php" method="post" data-toggle="validator">
				<!--<div class="hidden1">-->
				<div class="form-group row">
					<h3 style="text-align: center;">Team Leader</h3>
					<label for="firstname" class="col-form-label col-sm-2 col-md-2">First Name:</label>
					<div class="col-sm-10 col-md-10"><input type="text" name="firstname"class="form-control" id="firstname" placeholder="First Name" data-error="Enter Your First Name" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="lastname" class="col-form-label col-sm-2 col-md-2">Last Name:</label>
					<div class="col-sm-10 col-md-10"><input type="text" name="lastname" class="form-control" id="lastname" placeholder="Last Name" data-error="Enter Your Last Name" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="enroll" class="col-form-label col-sm-2 col-md-2">Enrollment Number :</label>
					<div class="col-sm-10 col-md-10"><input type="text" name="enrollmentno" class="form-control" id="enroll" placeholder="Enrollment Number" data-error="Enter Your Enrollment Number" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="inputEmail" class="col-form-label col-sm-2 col-md-2">Email:</label>
					<div class="col-sm-10 col-md-10"><input type="email" name="email" class="form-control" id="inputEmail" placeholder="Email" data-error="This email address is invalid" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="Phone" class="col-form-label col-sm-2 col-md-2">Phone:</label>
					<div class="col-sm-10 col-md-10"><input type="text" name="phone" class="form-control" id="Phone" placeholder="Phone" data-error="Enter Your Phone Number" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="college" class="col-form-label col-sm-2 col-md-2">College Name:</label>
					<div class="col-sm-10 col-md-10"><input type="text" name="college" class="form-control" id="college" placeholder="College Name" data-error="College Name invalid" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="gender" class="col-sm-2 col-md-2">Gender</label>
					<div class="col-sm-4 col-md-4">
						<input type="radio" name="gender" id="hire" value="male" checked>Male &nbsp;
						<input type="radio" name="gender" id="work" value="female">Female
					</div>
					<div class="col-md-8 col-sm-8"></div>
				</div>
				<div class="form-group row">
					<label for="volunteer_id" class="col-form-label col-sm-2 col-md-2">volunteer Id:</label>
					<div class="col-sm-10 col-md-10"><input type="text" name="volunteerid" class="form-control" id="volunteer_id" placeholder="volunteer Id" data-error="Enter Your volunteer Id" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
			</div>
				<!--<div class="hidden2">-->
				
				<?php
        $i=1;
        while ($i<=$member){
        ?>
				<h1 class="title">Registration of member 2</h1>
				<br>
				<div class="form-group row">
					<h3 style="text-align: center;">Member 2</h3>
					<label for="firstname" class="col-form-label col-sm-2 col-md-2">First Name:</label>
					<div class="col-sm-10 col-md-10"><input type="text" class="form-control" id="firstname" placeholder="First Name" data-error="Enter Your First Name" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="lastname" class="col-form-label col-sm-2 col-md-2">Last Name:</label>
					<div class="col-sm-10 col-md-10"><input type="text" class="form-control" id="lastname" placeholder="Last Name" data-error="Enter Your Last Name" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="enroll" class="col-form-label col-sm-2 col-md-2">Enrollment Number :</label>
					<div class="col-sm-10 col-md-10"><input type="text" class="form-control" id="enroll" placeholder="Enrollment Number" data-error="Enter Your Enrollment Number" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="inputEmail" class="col-form-label col-sm-2 col-md-2">Email:</label>
					<div class="col-sm-10 col-md-10"><input type="email" class="form-control" id="inputEmail" placeholder="Email" data-error="This email address is invalid" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="Phone" class="col-form-label col-sm-2 col-md-2">Phone:</label>
					<div class="col-sm-10 col-md-10"><input type="text" class="form-control" id="Phone" placeholder="Phone" data-error="Enter Your Phone Number" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="college" class="col-form-label col-sm-2 col-md-2">College Name:</label>
					<div class="col-sm-10 col-md-10"><input type="text" class="form-control" id="college" placeholder="College Name" data-error="College Name invalid" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group row">
					<label for="gender" class="col-sm-2 col-md-2">Gender</label>
					<div class="col-sm-4 col-md-4">
						<input type="radio" name="work" id="hire" value="male" checked>Male &nbsp;
						<input type="radio" name="work" id="work" value="female">Female
					</div>
					<div class="col-md-8 col-sm-8"></div>
				</div>
				<div class="form-group row">
					<label for="volunteer_id" class="col-form-label col-sm-2 col-md-2">volunteer Id:</label>
					<div class="col-sm-10 col-md-10"><input type="text" class="form-control" id="volunteer_id" placeholder="volunteer Id" data-error="Enter Your Payment Id" required>
					<div class="help-block with-errors"></div>
					</div>
				</div>
				</div>
			<div class="form-group">
					<INPUT type="submit" name="submit">
				</div>
		</form>
		<?php 
        $i=$i+1;
        }?>
	</div>
</div>
</div>
				
</body>
</html>