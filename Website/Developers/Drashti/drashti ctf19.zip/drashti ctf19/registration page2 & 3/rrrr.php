<?php
    $main=$_POST['mainevent'];
    $sub=$_POST['subevent'];
    $member=$_POST['members'];
    
?>
<html>
<head>
<title>ctf19</title>
</head>
<body>

  <?php
    echo $main;
    echo $sub;
    echo $member;
    ?>
	
</body>
</html>		