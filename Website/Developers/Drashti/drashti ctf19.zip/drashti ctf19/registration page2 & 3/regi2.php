<html>
<head>
<title>ctf19</title>
</head>
<body>
<?php
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$enrollmentno=$_POST['enrollmentno'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$college=$_POST['college'];
$volunteerid=$_POST['volunteerid'];
$gender=$_POST['gender'];

$con=mysql_connect("localhost","root","") or die ("Could not connect Database");
	mysql_select_db("ctf19",$con);
$sql=mysql_query("INSERT INTO registration(firstName,lastName,email,phone,college,enroll,gender) VALUES ('$firstname','$lastname','$email','$phone','$college','$enrollmentno','$gender')");
		if($sql)
		{
			include('thankyou.php');
		}
		else
		{
include('regi2.php');
	}
?>
  <br><br>  
<br><br><br><br>  
<br><bR>
<br><br>
	</form>
</body>
</html>		