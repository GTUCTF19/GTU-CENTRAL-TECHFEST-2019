<?php
$num=3;
?>
<html>
    <head>
        <title>DEMO</title>
    
    </head>
    <body>
    <form method="post">
        NAME : <input type="text"><br>
        SURNAME : <input type="text"><br>
        <input type="submit">
        </form>
        <?php
        $i=1;
        while ($i<=$num){
        ?>
        <form method="post">
        NAME : <input type="text"><br>
        SURNAME : <input type="text"><br>
        <input type="submit">
        </form>
        <?php 
        $i=$i+1;
        }?>
    </body>
</html>