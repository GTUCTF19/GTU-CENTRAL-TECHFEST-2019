<html>
<head>
<title>ctf19</title>
</head>
<body>
<?php
$name=$_POST['name'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$dept=$_POST['dept'];
$sub=$_POST['categary'];
$con=mysql_connect("localhost","root","") or die ("Could not connect Database");
	mysql_select_db("ctf19",$con);
		if($_POST['categary'] == "Event Manager")
		{
$sql=mysql_query("INSERT INTO manager(name,phone,email,department) VALUES ('$name','$phone','$email','$dept')");
		if($sql)
		{
			include('thankyou.php');
		}
		}
		else if($_POST['categary']== "Volunteer")
		{
$sql1=mysql_query("INSERT INTO volunteer(name,phone,email,department) VALUES ('$name','$phone','$email','$dept')");
		if($sql1)
		{
			include('thankyou.php');
		}
		}
		else if($_POST['categary'] == "Co-ordinator")
		{
$sql2=mysql_query("INSERT INTO coordinator(name,phone,email,department) VALUES ('$name','$phone','$email','$dept')");
		if($sql2)
		{
			include('thankyou.php');
		}
		}
		else{
			include('form.php');
		}
?>
 <br><br>  
<br><br><br><br>  
<br><bR>
<br><br>
</form>
</body>
</html>		