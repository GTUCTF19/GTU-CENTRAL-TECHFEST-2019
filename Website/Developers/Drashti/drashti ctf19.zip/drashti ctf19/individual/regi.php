<!DOCTYPE html>

<html>
<head>
<title> VAA Registration Form</title>
</head>
<?php
$con=mysql_connect("localhost","root","") or die ("Could not connect Database");
	mysql_select_db("vaa",$con);
	
	?>
<body>
<center>
<div>
	  <header>
				<h1> Registration Form </h1>
            </header>       
      <div>

    		<form action="registration2.php" method="POST"> 
			<fieldset>
    			<p><label for="name">Name : </label>
    			<input id="name" name="name" placeholder="First and last name" required="" tabindex="1" type="text"> 
    			<p><label for="mob_no">Mobile No. : </label> 
            <input type="number" id="mob_no" name="mob_no" placeholder="phone number" required="" type="number"> <br>
            <p><label for="email">Email :</label>
    			<input id="email" name="email" placeholder="example@domain.com" required="" type="email">
		       
<p><label for="password">Create a password :</label> 
    			<input type="password" id="password" name="password" required="">  
        
            
              
              <p><label for="role">Committe Member Role : </label> 
	              <select name="role[]">
	                <option value="xx">xx</option> 
	                <br>
	                <option value="yy">yy</option>
	                <br>
	                <option value="zz">zz</option>
	                <br>
                </select>
              </p>
              <p><label for="image">Image</label>
			  <input type="file" name="image" accept="image/*">
			  	          </p>
	          
              
            
            <input class="buttom" name="submit" id="submit" tabindex="5" value="Sign me up!" type="submit"> 	 
   </fieldset></form> 
   
</div>      
</div>
</center>
</body>
<?php mysql_close($con) ?>;
</html>
