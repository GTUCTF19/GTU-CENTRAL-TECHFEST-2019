<html>
<head>
<title>ctf19</title>
</head>
<body>
<?php
$name=$_POST['name'];
$phone=$_POST['phone'];

$con=mysql_connect("localhost","root","") or die ("Could not connect Database");
	mysql_select_db("ctf19",$con);
$sql=mysql_query("INSERT INTO volunteer(name,phone) VALUES ('$name','$phone')");
		if($sql)
		{
			include('thankyou.php');
		}
		else
		{
include('volunteer.php');
	}
?>
  <br><br>  
<br><br><br><br>  
<br><bR>
<br><br>
	</form>
</body>
</html>		