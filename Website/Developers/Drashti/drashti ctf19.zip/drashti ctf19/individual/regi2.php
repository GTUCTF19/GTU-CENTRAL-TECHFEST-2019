<html>
<head>
<title>vaa</title>
</head>
<body>
<?php
$name=$_POST['name'];
$mob_no=$_POST['mob_no'];
$email=$_POST['email'];
$password=$_POST['password'];
$role=$_POST['role'];
$image=$_POST['image'];


$check=" ";
if (!empty($_POST['role']))
{
$role = implode(",",$_POST['role']);
}
$con=mysql_connect("localhost","root","") or die ("Could not connect Database");
	mysql_select_db("vaa",$con);
$sql=mysql_query("INSERT INTO registration(name,mob_no,email,password,role,image) VALUES ('$name','$mob_no','$email','$password','$role','$image')");
		
		if($sql)
		{
 
			include('thankyou.php');

		
		}
		else
		{
include('registration.php');


	}?>
  <br><br>  
<br><br><br><br>  
<br><bR>
<br><br>
	</form>
</body>
</html>		