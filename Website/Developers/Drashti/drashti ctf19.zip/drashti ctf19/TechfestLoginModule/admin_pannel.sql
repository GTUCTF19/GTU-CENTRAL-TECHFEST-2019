-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 28, 2019 at 05:31 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `techfest`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_pannel`
--

DROP TABLE IF EXISTS `admin_pannel`;
CREATE TABLE IF NOT EXISTS `admin_pannel` (
  `u_name` varchar(40) NOT NULL,
  `u_id` varchar(10) NOT NULL,
  `u_pass` varchar(20) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_pannel`
--

INSERT INTO `admin_pannel` (`u_name`, `u_id`, `u_pass`) VALUES
('atv2@gmail.com', 'ATV', 'mainatv2'),
('bshah@gmail.com', 'b5', 'bs12'),
('entresum@gmail.com', 'ENSM', 'mainentresum'),
('nontechevents@gmail.com', 'NONTECH', 'mainnontech'),
('robotics@gmail.com', 'ROBO', 'mainrobotics'),
('techevents@gmail.com', 'TECH', 'maintechevent'),
('main@gmail.com', 'WEB', 'mainwebteam'),
('workshop@gmail.com', 'WKSP', 'mainworkshop');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
