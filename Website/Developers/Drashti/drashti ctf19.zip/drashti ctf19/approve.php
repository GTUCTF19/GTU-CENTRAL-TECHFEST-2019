<?php
$con=mysql_connect("localhost","root","") or die ("Could not connect Database");
	mysql_select_db("ctf19",$con);
$query=mysql_query("select * from manager ");
$row=mysql_fetch_assoc($query);	
	if(isset($_POST['update']))
	{
	$id=$_POST['id'];
	$uq="update manager SET status=1 WHERE id='$id'";
	mysql_query($uq);
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=/ctf_registration/manage_manager.php">';
		}
?>             <center><h4>Edit Information</h4></center>
						<center>
			 <form method="post" name="editform">
			 <table border=1>
			 <tr>
			 <td>Id: </td>
			 <td><input type="text" name="id" value="<?php echo $row['id']; ?>"></td>
			 </tr>
			 <tr>
			 <td colspan="2"><center><input type="submit" name="update" value="Update"></center></td>
			 </tr>
			 </table>
			 </form>
			 </center>
			 </table>
			 </form>
			 </center>
	  </div>

</body>
</html>