
<html>
<title>Admin</title>
<body>
             <center><h4>Manage Registered Student</h4></center>
			 <?php
			 echo "<center>";
			 $con=mysql_connect("localhost","root","") or die ("Could not connect Database");
			 mysql_select_db("ctf19",$con);
			 $q="SELECT * from manager";
		$result=mysql_query($q);
		
		 if($result === FALSE)
		{
            die("Query Failed!".mysql_error().$result);
		}
		echo "<table border=3>";
		echo "<center>
		<th style='padding-left:10px;padding-right:10px;'>id</th>
		<th style='padding-left:10px;padding-right:10px;'>name</th>
		<th style='padding-left:10px;padding-right:10px;'>phone</th>
		<th style='padding-left:10px;padding-right:10px;'>email</th>
		<th style='padding-left:10px;padding-right:10px;'>department</th>
		<th style='padding-left:10px;padding-right:10px;'>status</th>
		<th colspan=10 style='padding-left:10px;padding-right:10px;'>Action </th></center>";
		while($row= mysql_fetch_assoc($result) )
		{
			echo "<tr>";
			foreach($row as $v)
			{
				echo "<td style='padding:10px;'>".$v."</td>";
			}
	echo "<td><center><a href='approve.php?id=".$row['id']."'><img src='right.png' height='20' width='20'></a></center></td>";
                echo "<td><center><a href='remove.php?id=".$row['id']."'><img src='cross.jpg' height='20' width='20'></a></center></td>";
			echo "</tr>";
		}
		echo "</table>";
		echo "</center>";
mysql_close($con);
			?>
</body>
</html>
