<html>
<body>
<?php
$con=mysql_connect("localhost","root","") or die ("Could not connect Database");
	mysql_select_db("ctf19",$con);
	
if(isset($_GET['id']))
{
$id=$_GET['id'];
$query1=mysql_query("delete from volunteer where id='$id'");
if($query1)
{
header('location:manage_volunteer.php');
}
}
?>
</body>
</html>